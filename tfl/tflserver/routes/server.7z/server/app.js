const express = require("express");
//引入用户路由器
//引用菜品路由
const userRouter=require('./routes/shop.js');
// 引用登录注册路由
const loginRouter=require("./routes/login.js");
// 引入中间件
const bodyParser = require("body-parser");
const cors=require("cors");
// 创建服务器
var app = express();
// 设置跨域请求
app.use('/', function (req, res, next) {
	// 设置请求头为允许跨域
    res.header("Access-Control-Allow-Origin", "*");
    // 设置服务器支持的所有头信息字段
    res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
    // 设置服务器支持的所有跨域请求的方
    res.header("Access-Control-Allow-Methods", "POST,GET");
    // next()方法表示进入下一个路由
    next();
});
// 监听端口
app.listen(3000);
app.use( bodyParser.urlencoded({
    extended:false  //不是第三方的qs模块，而是使用querystring模块
  })
 );

//使用路由器,
// /user/reg
app.use( '/user',userRouter);
// 使用路由器管理登录注册路由
app.use("/",loginRouter);