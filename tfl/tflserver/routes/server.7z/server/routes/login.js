const express=require("express");
const router=express.Router();
const pool=require("../pool");

// 登录组件
router.post("/login",function(req,res){
  // var uname = req.query.uname;
  // var upwd = req.query.upwd;
  var obj = req.body;
  var sql = 'select * from tfl_user where uname = ? and upwd = ?'
  // console.log(sql);
  pool.query(sql,[obj.uname,obj.upwd],(err,result)=>{
    if(err) throw err;
    console.log(result);
    // 判断数据长度是否大于0
    if(result.length>0){
      res.send({status:1,msg:"登录成功"});
    }else{
      res.send({status:-1,msg:"用户名或密码错误登录失败！"})
    }
  })
})

// 注册组件
router.post('/reg',(req,res)=>{
    // 获取post请求的数据
    var obj = req.body;
    // 查询语句
    var sql = 'select * from tfl_user where uname = ? and upwd = ?'
    // 插入语句
    var insert = 'insert into tfl_user set ?'
    pool.query(sql,[obj.uname,obj.upwd],(err,result)=>{
      if(err) throw err;
      if(result.length!==0){
        console.log(result);
        res.send({status:1,msg:'该用户名或密码已经存在！'})
      }else{
        pool.query(insert,[obj],(err,result)=>{
            if(err) throw err;
            if(result.affectedRows==1){
              res.send({status:1,msg:'注册成功'})
            }
        })
      }
    })
})
module.exports=router;