const express = require('express');
// 引入商品路由器
const productRouter = require('./routes/product.js');
// 引入body-parser中间件
const bodyParser = require('body-parser');
// 引入解决跨域问题文件
const cors=require("cors");
var app = express();
app.listen(8080);
// 解决跨域问题
app.use(cors({
    origin:"http://localhost:8080"//不能用*
  }));

// 托管静态资源到public目录中
app.use(express.static('public'));
// 使用body-parser中间件
app.use(bodyParser.urlencoded({
    extended: false //不使用第三方模块，而是使用querystring模块
}));

// 使用路由器
// /product
app.use('/product', productRouter);