const express = require('express');
// 引入连接池模块
const pool = require('../pool.js');
// 创建路由器对象
var router = express.Router();

// 添加路由
// 1.商品列表
router.get('/list', function(req, res) {
    // 1.1获取数据
    var obj = req.query;
    // 1.2将数据转化为整型
    obj.pno = parseInt(obj.pno);
    obj.pageSize = parseInt(obj.pageSize);
    // 1.3验证数据是否为空
    if (!obj.pno) obj.pno = 1;
    if (!obj.pageSize) obj.pageSize = 2;
    // 1.4设置每页的开始
    var start = (obj.pno - 1) * obj.pageSize;
    // 1.5执行sql语句，把结果响应给浏览器端
    pool.query('select * from tfl_index_product limit ?,?', [start, obj.pageSize], function(err, result) {
        if (err) throw err;
        res.send(result);
    });
});

// 2.商品详情
router.get('/detail', function(req, res) {
    // 2.1获取数据
    var obj = req.query;
    // 2.2验证数据是否为空
    if (!obj.pid) {
        res.send({ code: 401, msg: 'pid required' });
        return;
    };
    // 2.3执行sql语句
    pool.query('select * from tfl_index_product where pid=?', [obj.pid], function(err, result) {
        if (err) throw err;
        res.send(result);
    });
});

// 3.删除商品
router.get('/delete', function(req, res) {
    // 3.1获取数据
    var obj = req.query;
    console.log(obj);
    // 3.2验证数据是否为空
    if (!obj.pid) {
        res.send({ code: 401, msg: "pid required" });
    };
    // 3.3执行SQL语句
    pool.query('delete from tfl_index_product where pid=?', [obj.pid], function(err, result) {
        if (err) throw err;
        console.log(result);
        if (result.affectedRows > 0) {
            res.send({ code: 200, msg: "delete success" });
        } else {
            res.send({ code: 301, msg: "delete failure" });
        };
    });
});

// 导出路由器
module.exports = router;