const express = require('express');
// 引入连接池模块
const pool = require('../pool.js.js');
// 创建路由器对象
var router = express.Router();

// 添加路由
//1.用户注册
router.post('/reg', function(req, res) {
    // 获取post请求的数据
    var obj = req.body;
    // 验证每一项数据是否为空
    // 例如：用户名为空， 提示“用户名不能为空”
    if (!obj.uname) {
        res.send({ code: 401, msg: 'uname required' });
        // return 阻止往后执行
        return;
    } else if (!obj.upwd) {
        res.send({ code: 402, msg: 'upwd required' });
        return;
    } else if (!obj.email) {
        res.send({ code: 402, msg: 'email required' });
        return;
    } else if (!obj.phone) {
        res.send({ code: 403, msg: 'phone required' });
        return;
    };
    res.send('注册成功');
    // 执行sql语句
    pool.query('insert into tfl_user set ?', [obj], function(err, result) {
        if (err) throw err;
        console.log(result);
        //判断是否插入成功
        if (result.affectedRows > 0) {
            res.send({ code: 200, msg: 'reg success' })
        };
    });
});

// 2.用户登录
router.post('/login', function(req, res) {
    // 2.1获取数据
    var obj = req.body;
    // 2.2验证数据是否为空
    if (!obj.uname) {
        res.send({ code: 401, msg: 'uname required' });
        return;
    };
    if (!obj.upwd) {
        res.send({ code: 402, msg: 'upwd required' });
        return;
    };
    // 2.3执行sql语句
    pool.query('select * from tfl_user where uname = ? and upwd = ?', [obj.uname, obj.upwd], function(err, result) {
        if (err) throw err;
        console.log(result);
        if (result.length > 0) {
            res.send({ code: 200, msg: 'login success' });
        } else {
            res.send({ code: 301, msg: 'login failure' });
        };
    });
});

// 3.检索用户
router.get('/detail', function(req, res) {
    // 3.1获取数据
    var obj = req.query;
    console.log(obj);
    // 3.2验证编号是否为空
    if (!obj.uid) {
        res.send({ code: 401, msg: 'uid required' });
        return;
    }
    // 3.3执行sql语句
    pool.query('select * from tfl_user where uid=?', [obj.uid], function(err, result) {
        if (err) throw err;
        // 把查询到的数据响应到浏览器中
        res.send(result);
    });
});

// 4.修改列表
router.get('/update', function(req, res) {
    // 4.1获取数据
    var obj = req.query;
    // 4.2验证数据是否为空
    // 批量验证，获取每个属性，然后判断是否为空
    var i = 400;
    for (var key in obj) {
        i++;
        // 判断属性值是否为空
        if (!obj[key]) {
            res.send({ code: i, msg: key + 'required' });
            return;
        };
    };

    // 4.3执行sql语句
    pool.query('update tfl_user set email=? , phone=? , user_name=? , gender=? where uid=?', [obj.email, obj.phone, obj.user_name, obj.gender, obj.uid], function(err, result) {
        if (err) throw err;
        console.log(result);
        // 判断是否修改成功
        if (result.affectedRows > 0) {
            res.send({ code: 200, msg: 'update success' });
        } else {
            res.send({ code: 401, msg: 'update failure' });
        };
    });
});

// 5.用户列表
router.get('/list', function(req, res) {
    // 5.1获取数据
    var obj = req.query;
    // 5.2将数据转成整型
    obj.pno = parseInt(obj.pno);
    obj.size = parseInt(obj.size);
    // 5.3验证数据是否为空
    if (!obj.pno) obj.pno = 1; //设置默认页码1
    if (!obj.size) obj.size = 2; //设置默认大小为2
    // 5.4计算每页的开始
    var start = (obj.pno - 1) * obj.size;
    // 5.5执行sql语句，把结果响应给浏览器端
    pool.query('select * from tfl_user limit ?,?', [start, obj.size], function(err, result) {
        if (err) throw err;
        res.send(result);
    });
});

// 6.删除用户
router.get('/delect', function(req, res) {
    // 6.1获取数据
    var obj = req.query;
    //6.2验证数据是否为空
    if (!obj.uid) {
        res.send({ code: 401, msg: 'uid required' });
        return;
    };
    // 6.3执行sql语句
    pool.query('Delete from tfl_user where uid=?', [obj.uid], function(err, result) {
        if (err) throw err;
        console.log(result);
        if (result.affectedRows > 0) {
            res.send({ code: 200, msg: 'delete success' });
        } else {
            res.send({ code: 401, msg: 'delete failure' });
        };
    });
});

// 导出路由器
module.exports = router;